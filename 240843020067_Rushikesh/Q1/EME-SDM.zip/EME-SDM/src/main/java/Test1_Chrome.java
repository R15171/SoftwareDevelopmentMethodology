import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Test1_Chrome {

	public static void main(String[] args) {

		WebDriverManager.edgedriver().setup();
		WebDriver driver= new EdgeDriver();
		driver.get("https://parabank.parasoft.com");
		driver.manage().window().maximize();
		
		driver.findElement(By.xpath("//*[@name=\"username\"]")).sendKeys("standard_user@gmail.com");
		driver.findElement(By.name("password")).sendKeys("123456");
		
	}
}
